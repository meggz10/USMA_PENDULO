#!/bin/bash
killall python3
python3 main.py
